package model;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name = "customer")
@SessionScoped

public class Customer {
	
	private Long transCode;
	private String firstName;
	private String surname;
	private String sPassport;
	private String desPassport;
	private String desBank;
	private String desCountry;
	private int accNumber;
	private Double amnt;
	
	//private int transCode;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public String getsPassport() {
		return sPassport;
	}
	public void setsPassport(String sPassport) {
		this.sPassport = sPassport;
	}
	public String getDesPassport() {
		return desPassport;
	}
	public void setDesPassport(String desPassport) {
		this.desPassport = desPassport;
	}
	public String getDesBank() {
		return desBank;
	}
	public void setDesBank(String desBank) {
		this.desBank = desBank;
	}
	public String getDesCountry() {
		return desCountry;
	}
	public void setDesCountry(String desCountry) {
		this.desCountry = desCountry;
	}
	public int getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}
	public Double getAmnt() {
		return amnt;
	}
	public void setAmnt(Double amnt) {
		this.amnt = amnt;
	}
	public Long getTransCode() {
		return transCode;
	}
	public void setTransCode(Long transCode) {
		this.transCode = transCode;
	}
	
	public CustomerEntity getEntity() {
		CustomerEntity customerEntity = new CustomerEntity();
		customerEntity.setFirstName(firstName);
		customerEntity.setSurname(surname);
		customerEntity.setsPassport(sPassport);
		customerEntity.setDesPassport(desPassport);
		customerEntity.setDesBank(desBank);
		customerEntity.setDesCountry(desCountry);
		customerEntity.setAccNumber(accNumber);
		customerEntity.setAmnt(amnt);
		//customerEntity.setId(id);
		return customerEntity;
	}

}
