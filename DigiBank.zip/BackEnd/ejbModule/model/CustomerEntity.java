package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "customer_tbl")
public class CustomerEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long transCode;
	
	private String firstName;
	private String surname;
	private String sPassport;
	private String desPassport;
	private String desBank;
	private String desCountry;
	private int accNumber;
	private Double amnt;
	//private int transCode;
	
	public Long getTransCode() {
		return transCode;
	}
	public void setTransCode(Long transCode) {
		this.transCode = transCode;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public String getsPassport() {
		return sPassport;
	}
	public void setsPassport(String sPassport) {
		this.sPassport = sPassport;
	}
	public String getDesPassport() {
		return desPassport;
	}
	public void setDesPassport(String desPassport) {
		this.desPassport = desPassport;
	}
	public String getDesBank() {
		return desBank;
	}
	public void setDesBank(String desBank) {
		this.desBank = desBank;
	}
	public String getDesCountry() {
		return desCountry;
	}
	public void setDesCountry(String desCountry) {
		this.desCountry = desCountry;
	}
	public int getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}
	public Double getAmnt() {
		return amnt;
	}
	public void setAmnt(Double amnt) {
		this.amnt = amnt;
	}
	/**public int getTransCode() {
		return transCode;
	}
	public void setTransCode(int transCode) {
		this.transCode = transCode;
	}**/
	
	

}
